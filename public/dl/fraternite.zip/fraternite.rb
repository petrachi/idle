#!/usr/bin/env ruby

require 'capybara'
require 'capybara/dsl'
require 'capybara/poltergeist'

include Capybara::DSL
Capybara.default_driver = :poltergeist

require "twilio-ruby"
require 'mail'



options = { :address              => "smtp.gmail.com",
            :port                 => 587,
            :domain               => 'exemple.fr',
            :user_name            => 'your@gmail.com', # change here
            :password             => 'passwd', # change here
            :authentication       => 'plain',
            :enable_starttls_auto => true  }

Mail.defaults do
  delivery_method :smtp, options
end

def send_mail p_subject, p_body
  Mail.deliver do
         to 'their@gmail.com' # change here
       from 'your@gmail.com' # change here
    subject p_subject
       body p_body
  end
end



def check_planning
  visit "http://www.haute-garonne.gouv.fr/booking/create/7736/1" # change here

  checkboxe_values = Array.new

  all("#FormBookingCreate input[type=radio]").each do |input|
    checkboxe_values << input.value
  end

  checkboxe_values.each_with_index do |checkbox_value, i|
    visit "http://www.haute-garonne.gouv.fr/booking/create/7736/1" # change here

    within("#FormBookingCreate") do
      find(:xpath, "//input[@value=#{checkbox_value}]").set(true)
    end
    click_button 'Etape suivante'

    begin
      text = find("#FormBookingCreate").text

      if text != "Il n'existe plus de plage horaire libre pour votre demande de rendez-vous. Veuillez recommencer ultérieurement."
        client = Twilio::REST::Client.new(ENV["ACCOUNT_SID"], ENV["AUTH_TOKEN"]) # change here
        client.messages.create from: "+33 X XX XX XX XX", to: "+33 X XX XX XX XX", :body => "Le guichet #{i+1} à l'air ouvert !" # change here
        send_mail '/!\ Nationalité FR - Planning', "C'est ta chance ! Le guichet #{i+1} à l'air ouvert !"
      end

    rescue Capybara::ElementNotFound => e
      send_mail '/!\ Nationalité FR - Planning', "La page de retour n'est pas celle anticipé, ça peut-être un bug, ou bien c'est ta chance (guichet #{i+1}) ?"
    end
  end
rescue => e
  send_mail '/!\ Nationalité FR - Planning', "Error : #{e}"
end



while true
  p "check at #{Time.now}"
  check_planning
  sleep(300)
end
